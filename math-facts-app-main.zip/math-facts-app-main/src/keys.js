// <script type="module">
// Import the functions you need from the SDKs you need
// import { initializeApp } from "https://www.gstatic.com/firebasejs/9.16.0/firebase-app.js";
// import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.16.0/firebase-analytics.js";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyDnQMHfV10DstXyQs1DqZ_j8HnM3ydWX1A",
    authDomain: "numbers-nerd-get-the-facts.firebaseapp.com",
    projectId: "numbers-nerd-get-the-facts",
    storageBucket: "numbers-nerd-get-the-facts.appspot.com",
    messagingSenderId: "475927340459",
    appId: "1:475927340459:web:6b8878de47b3905be01eee",
    measurementId: "G-HWP24NBPFC"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
{/*</script>*/}

